create definer = root@localhost view longtime_employees as
select `labs`.`employees`.`second_name`                                             AS `name`,
       `labs`.`employees`.`first_name`                                              AS `last_name`,
       floor(((to_days(curdate()) - to_days(`labs`.`employees`.`hire_date`)) / 30)) AS `experience`
from `labs`.`employees`
order by floor(((to_days(curdate()) - to_days(`labs`.`employees`.`hire_date`)) / 30)) desc
limit 10;

