create definer = root@localhost trigger TR_Employees_Delete
    after delete
    on employees
    for each row
BEGIN
    CALL AppendLogInfo('Delete',CONCAT('Сотрудник ', OLD.second_name, ' ', OLD.first_name, ' был удален из компании.'));
END;

