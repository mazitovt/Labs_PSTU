create
    definer = root@localhost procedure InsertPhones()
BEGIN
DECLARE x int DEFAULT 100;
DECLARE num varchar(20);
	WHILE x < 200 DO
		SET num  = CONCAT('+7 (',
		  					CONVERT(FLOOR(900 + (RAND() * 100)),char),') ',
		 					CONVERT(FLOOR(100 + (RAND() * 900)),char), '-',
		 					CONVERT(FLOOR(10 + (RAND() * 90)),char),'-',
		 					CONVERT(FLOOR(10 + (RAND() * 90)),char));
		INSERT INTO labs.phones VALUES (x, num, 'Cellphone');
		SET x = x + 1; 
	END WHILE;
END;

