create
    definer = root@localhost procedure AppendLogInfo(IN ev varchar(30), IN des varchar(200))
BEGIN
    INSERT INTO labs.log (time, event, `table`, description) VALUES (current_time(), ev,'Employees', des);
END;

