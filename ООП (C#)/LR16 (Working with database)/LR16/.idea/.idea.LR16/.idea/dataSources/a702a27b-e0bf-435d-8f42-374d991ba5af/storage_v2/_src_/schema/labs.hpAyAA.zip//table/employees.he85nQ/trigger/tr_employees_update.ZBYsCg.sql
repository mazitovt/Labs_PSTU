create definer = root@localhost trigger TR_Employees_Update
    after update
    on employees
    for each row
BEGIN
    DECLARE flag BOOL DEFAULT FALSE;
    IF OLD.first_name <> NEW.first_name THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Фамилия\' изменено с ', OLD.first_name,' на ', NEW.first_name));
        set flag = TRUE;
    END IF;

    IF OLD.second_name <> NEW.second_name THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Имя\' изменено с ', OLD.second_name,' на ', NEW.second_name));
        set flag = TRUE;
    END IF;

    IF OLD.third_name <> NEW.third_name THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Отчество\' изменено с ', OLD.third_name,' на ', NEW.third_name));
        set flag = TRUE;
    END IF;

    IF OLD.job_id <> NEW.job_id THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Должность\' изменено с ', OLD.job_id,' на ', NEW.job_id));
        set flag = TRUE;
    END IF;

    IF OLD.department_id <> NEW.department_id THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Департамент\' изменено с ', OLD.department_id,' на ', NEW.department_id));
        set flag = TRUE;
    END IF;

    IF OLD.salary <> NEW.salary THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Зарплата\' изменено с ', OLD.salary,' на ', NEW.salary));
        set flag = TRUE;
    END IF;

    IF OLD.manager_id <> NEW.manager_id THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' поле \'Начальник\' изменено с ', OLD.manager_id,' на ', NEW.manager_id));
        set flag = TRUE;
    END IF;

    IF flag = FALSE THEN
        CALL AppendLogInfo('Update', concat('У записи ', OLD.employee_id, ' были произведены изменения'));
    END IF;
END;

