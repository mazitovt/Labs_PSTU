create definer = root@localhost view it_employees as
select `e`.`employee_id` AS `id`, `e`.`first_name` AS `last_name`, `e`.`second_name` AS `name`
from (`labs`.`employees` `e`
         join `labs`.`departments` `d` on ((`e`.`department_id` = `d`.`department_id`)))
where (`d`.`department_name` = 'IT');

