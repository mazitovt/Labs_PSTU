create definer = root@localhost trigger TR_Employees_Insert
    after insert
    on employees
    for each row
BEGIN
    set @des = CONCAT('Сотрудник ', NEW.second_name, ' ', NEW.first_name,' был добавлен в компанию.');
    INSERT INTO labs.log (time, event, `table`, description) VALUES (current_time(), 'Insert','Employees', @des);
END;

