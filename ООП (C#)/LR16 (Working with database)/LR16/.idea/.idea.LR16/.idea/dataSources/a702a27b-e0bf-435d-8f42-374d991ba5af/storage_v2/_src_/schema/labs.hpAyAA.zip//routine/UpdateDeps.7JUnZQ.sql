create
    definer = root@localhost procedure UpdateDeps()
BEGIN
    SET @x = 1;
    SELECT COUNT(*) INTO @x FROM labs.departments;
    WHILE @x != 0 DO
        UPDATE labs.departments SET manager_id = (SELECT employee_id FROM labs.employees ORDER BY RAND() LIMIT 1) WHERE manager_id IS not NULL;
        set @x = @x - 1;
    END WHILE;
END;

