create
    definer = root@localhost procedure InsertEmps()
BEGIN
DECLARE x int DEFAULT 10000;
	WHILE x < 10100 DO
		INSERT INTO labs.employees VALUES 
		(
			x,
			(SELECT first_name FROM labs.tempEmp ORDER BY RAND() LIMIT 1),
			(SELECT second_name FROM labs.tempEmp ORDER BY RAND() LIMIT 1),
			(SELECT third_name FROM labs.tempEmp ORDER BY RAND() LIMIT 1),
			(SELECT CURDATE() - INTERVAL FLOOR(30 + RAND() * 330) DAY),
			(SELECT FLOOR(10 + (RAND() * 90))),
			(SELECT department_id FROM labs.departments ORDER BY RAND() LIMIT 1),
			1001,
			(SELECT phone_id FROM labs.phones ORDER BY RAND() LIMIT 1),
			(SELECT phone_id FROM labs.phones ORDER BY RAND() LIMIT 1),
			(SELECT FLOOR(50000 + (RAND() * 250000))),
			'Россия',
			(SELECT city FROM labs.tempemp ORDER BY RAND() LIMIT 1),
			(SELECT street FROM labs.tempemp ORDER BY RAND() LIMIT 1),
			(SELECT FLOOR(1 + (RAND() * 49))),
			(SELECT FLOOR(10 + (RAND() * 290)))		
		);
		SET x = x + 1; 
	END WHILE;
END;

