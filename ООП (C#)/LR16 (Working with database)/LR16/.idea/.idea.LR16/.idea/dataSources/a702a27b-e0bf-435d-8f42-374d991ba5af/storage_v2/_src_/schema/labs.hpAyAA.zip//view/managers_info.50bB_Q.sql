create definer = root@localhost view managers_info as
select `t`.`team` AS `team`, count(0) AS `managers`
from (select (select count(`labs`.`employees`.`employee_id`)
              from `labs`.`employees`
              where (`labs`.`employees`.`manager_id` = `e`.`employee_id`)) AS `team`
      from `labs`.`employees` `e`) `t`
where (`t`.`team` > 0)
group by `t`.`team`
order by `managers` desc;

